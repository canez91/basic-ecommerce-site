@extends('layouts.app')

@section('content')

			@include('products.form')

@endsection
