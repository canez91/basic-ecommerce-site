@extends('layouts.app')

@section('content')
<cms-home-page></cms-home-page>
@endsection