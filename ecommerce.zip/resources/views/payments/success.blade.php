@extends("layouts.shop")

@section("content")
	<h4 style="text-align: center">Tu compra fue completada</h4>
	<p style="text-align: center">Enviamos un email a tu correo para que puedas estar al tanto de tu envío.</p>
@endsection