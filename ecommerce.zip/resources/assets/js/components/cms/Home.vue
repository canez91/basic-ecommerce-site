<template>
  <v-app id="inspire">
    <cms-side-bar></cms-side-bar>
    <v-content>
      <v-container fluid fill-height>
        <v-layout justify-center align-center>
          
        </v-layout>
      </v-container>
    </v-content>
  </v-app>
</template>

<script>
  export default {
    data: () => ({

    }),
    props: {
      source: String
    }
  }
</script>