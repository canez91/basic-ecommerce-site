<?php $__env->startSection("content"); ?>
<v-app id="inspire">
	<cms-side-bar :title='<?php echo json_encode( $title ); ?>'></cms-side-bar>
	<v-content>
		<product-catalog
		  :products='<?php echo json_encode( $products ); ?>'
		></product-catalog>
	</v-content>

</v-app>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.app", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>