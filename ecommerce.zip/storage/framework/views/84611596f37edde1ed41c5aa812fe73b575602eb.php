<?php if(auth()->guard()->check()): ?>
  <?php echo Form::open(["method" => "DELETE" , "route" => ["products.destroy", $product->id]]); ?>


	<input type="submit" value="Eliminar producto" class="btn btn-danger" />
	
  <?php echo Form::close(); ?>

<?php endif; ?>
