<?php $__env->startSection("content"); ?>
	<h4 style="text-align: center">Tu compra fue completada</h4>
	<p style="text-align: center">Enviamos un email a tu correo para que puedas estar al tanto de tu envío.</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.shop", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>