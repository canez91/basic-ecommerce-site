<v-app id="inspire">
	<cms-side-bar :title='<?php echo json_encode( $title ); ?>'></cms-side-bar>
	<v-content>
		<product-form
			:product='<?php echo json_encode( $product ); ?>'
			:method='<?php echo json_encode( $product->method() ); ?>'
			:route='<?php echo json_encode( $product->url() ); ?>'
		></product-form>
	</v-content>
</v-app>
