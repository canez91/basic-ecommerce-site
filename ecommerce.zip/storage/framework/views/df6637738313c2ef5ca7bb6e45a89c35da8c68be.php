<?php $__env->startSection("content"); ?>

<!-- banner -->
	<div class="banner10" id="home1">
		<div class="container">
			<h2>Carrito</h2>
		</div>
	</div>
<!-- //banner -->

<!-- breadcrumbs -->
	<div class="breadcrumb_dress">
		<div class="container">
			<ul>
				<li><a href="/"><span class="glyphicon glyphicon-home" aria-hidden="true"></span> Inicio</a> <i>/</i></li>
				<li>Carrito</li>
			</ul>
		</div>
	</div>
<!-- //breadcrumbs -->

<!-- checkout -->
	<div class="checkout">
		<div class="container">
			<!--h3>Tu carrito contiene: <span><?php echo e($shopping_cart->productsCount()); ?> artículos</span></h3-->

			<cart-products-list></cart-products-list>
			
		</div>
	</div>	
	
	
<!-- //checkout -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.shop", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>