<?php

return [
	'name' => "Women's Fashion",
	'address' => "Est Eligendi Optio Cumque Nihil Impedit Quo Minus Id Quod Maxime 26 56D Rescue,US",
	'contact' => [
		'phone' => "+1 078 4589 2456",
		'freephone' => "+1 078 4589 2456",
		'fax' => "+1 078 4589 2456",
		'email' => "info@example.com",
	],
	'social' => [
		'facebook' => "https://www.facebook.com/w3layouts/",
		'twitter' => "https://twitter.com/W3layouts",
		'google' => "https://plus.google.com/+W3layouts"
	]
];